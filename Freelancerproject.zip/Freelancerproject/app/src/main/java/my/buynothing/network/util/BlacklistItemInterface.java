package my.buynothing.network.util;

public interface BlacklistItemInterface {

    public void remove(int position);
}